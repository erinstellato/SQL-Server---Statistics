/*
	prep for GOOD STATS
*/

USE [master];
GO
RESTORE DATABASE [WideWorldImportersB] 
	FROM  DISK = N'C:\Backups\WWI_Standard.bak' 
		WITH  FILE = 1,  
	MOVE N'WWI_Primary' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' 
		TO N'C:\Databases\WideWorldImportersLarge\WideWorldImporters.ldf',  
	NOUNLOAD,  
	REPLACE,  
	STATS = 5;
GO

USE [master]
GO
ALTER DATABASE [WideWorldImportersB] SET AUTO_UPDATE_STATISTICS ON WITH NO_WAIT
GO

USE WideWorldImportersB;
GO


UPDATE  Sales.Orders
SET CustomerID = 550
WHERE CustomerID = 45
AND SalesPersonPersonID IN (3,2,14,13,7)
GO


UPDATE  Sales.Orders
SET CustomerID = 861
WHERE CustomerID = 165
AND SalesPersonPersonID IN (20,7,3,8,15,14)
GO


UPDATE  Sales.Orders
SET CustomerID = 178
WHERE CustomerID = 1033
AND SalesPersonPersonID IN (13,16,20,3,7,8,6,14)
GO


UPDATE  Sales.Orders
SET CustomerID = 997
WHERE CustomerID = 1033
AND SalesPersonPersonID IN (7,16,2,13,20,6,14,8)
GO


UPDATE  Sales.Orders
SET CustomerID = 899
WHERE CustomerID = 522
GO


UPDATE  Sales.Orders
SET CustomerID = 906
WHERE CustomerID = 1046
GO


UPDATE  Sales.Orders
SET CustomerID = 558
WHERE CustomerID = 164
GO


UPDATE  Sales.Orders
SET CustomerID = 844
WHERE CustomerID = 81	
GO


UPDATE  Sales.Orders
SET CustomerID = 91
WHERE CustomerID = 	896
GO


UPDATE  Sales.Orders
SET CustomerID = 499
WHERE CustomerID = 	567
GO


UPDATE  Sales.Orders
SET CustomerID = 1005
WHERE CustomerID = 	22
GO


UPDATE  Sales.Orders
SET CustomerID = 1005
WHERE CustomerID = 100
AND SalesPersonPersonID IN (13)
GO



UPDATE  Sales.Orders
SET CustomerID = 910
WHERE CustomerID IN (1022, 5)
GO


UPDATE  Sales.Orders
SET CustomerID = 823
WHERE CustomerID IN (987, 991, 94)
GO


UPDATE  Sales.Orders
SET CustomerID = 834
WHERE CustomerID IN (815)
GO


UPDATE  Sales.Orders
SET CustomerID = 890
WHERE CustomerID IN (101,458,117)
GO


UPDATE  Sales.Orders
SET CustomerID = 464
WHERE CustomerID IN (80,596,1035)
GO


UPDATE  Sales.Orders
SET CustomerID = 108
WHERE CustomerID IN (1034,451,68,995)
GO


UPDATE  Sales.Orders
SET CustomerID = 591
WHERE CustomerID IN (1032,1012,448,956)
GO


UPDATE  Sales.Orders
SET CustomerID = 472
WHERE CustomerID IN (833,576,563,155)
GO


UPDATE  Sales.Orders
SET CustomerID = 907
WHERE CustomerID IN (965,140,866,480,992,437,408,515)
GO


UPDATE  Sales.Orders
SET CustomerID = 422
WHERE CustomerID IN (575,460,200,587,496,597,127,508,928,495,491,1064, 492, 54,13, 488,416,839,110,577,954)
GO


UPDATE STATISTICS Sales.Orders WITH FULLSCAN;
GO

USE [master]
GO
ALTER DATABASE [WideWorldImportersB] SET COMPATIBILITY_LEVEL = 150;
GO

GO

